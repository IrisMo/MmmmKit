//
//  MMBlue.h
//  MmmmKit
//
//  Created by minew on 2020/10/21.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MMBlue : NSObject

+ (instancetype)sharedInstance;


- (void)print;

@end

NS_ASSUME_NONNULL_END
